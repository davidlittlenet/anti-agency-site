# The Review Engine for Roofers

You are one roofer with a smaller review count than the company four miles away, and that
number is deciding which of you the homeowner calls.

This fixes that. It is a system for asking every customer, once, at the right moment — run
by your crew, not by you — and it takes about twenty minutes to set up.

**It is not software and there is nothing to subscribe to.** It is the process, the words,
and the printable cards.

---

## What is in here

| File | What it is |
|---|---|
| **01-THE-SYSTEM.md** | The playbook. Read this one first — about ten minutes. |
| **02-SCRIPTS.md** | Every script: the crew's fifteen-second line, the follow-up text, email, invoice line. |
| **03-REPLIES.md** | Reply templates for five-star down to one-star, plus fake reviews. |
| **04-WHAT-GETS-YOU-WIPED.md** | One page on what actually violates Google's rules. Read it before you build anything. |
| **05-tracker.csv** | The tracker. Opens in Excel, Numbers or Google Sheets. |
| **06-print-cards.html** | Makes your leave-behind cards, four to a sheet. Open it in any browser. |
| **06-PRINT-CARDS-README.md** | How to use that page. |

---

## If you only have twenty minutes today

1. Open your Google Business Profile and press **"Ask for reviews"**. Copy the link, save
   the QR code. *(Two minutes.)*
2. Open **06-print-cards.html**, fill in your company name and phone, add the QR code,
   print a sheet, cut it up, put the stack in the truck. *(Ten minutes.)*
3. Read the crew line at the top of **02-SCRIPTS.md** and send it to your crew chiefs.
   *(Three minutes.)*
4. Open **05-tracker.csv**, delete the example rows, keep the headers. *(One minute.)*

That is the engine running. Everything else sharpens it.

---

## The one thing to get right

Ninety percent of the failures with this are not the script and not the timing. They are
that **the card never left the truck.**

If your numbers are not moving in a month, do not rewrite the text message. Go and count
how many cards are left in the stack. That one question will tell you what is wrong.

---

## A word on the rules

Google removed a lot of review activity in 2026 and tightened the rules on incentives and
on-site review stations. Several things widely sold as best practice in this industry —
gating out unhappy customers, offering a discount for a review, handing over a tablet on
site — can cost you every review you have ever collected, not just the new ones.

Nothing in this system does any of that. **The same link goes to every customer, with
nothing attached to it.** That is not just the safe way, it is the way that produces a
profile homeowners actually believe.

---

*This kit is for one company's own use. Please don't resell or redistribute it.*
