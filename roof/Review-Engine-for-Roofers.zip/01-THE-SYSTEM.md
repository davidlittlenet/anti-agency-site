# The Review Engine for Roofers

**The whole system, in one line:** ask every customer once, at the moment they are
standing in the driveway looking at their new roof, with a link that takes one tap.

That is it. Everything else in this file is detail about how to make that happen when
you are not the one on the roof.

---

## Why roofing is different, and why generic review advice fails you

Most review advice is written for restaurants and salons — businesses that see the same
customer forty times a year and can ask again next visit. You do not get a next visit.
A roof lasts twenty-five years. **You get one chance per customer, and if you miss it,
that review is gone forever.**

Three things follow from that, and they shape the entire system:

**1. The moment matters more than the message.** A restaurant can send a mediocre text
next Tuesday. You have a window that opens when the homeowner sees the finished roof and
closes about seventy-two hours later, when the job stops being the most interesting thing
that happened to them that week. Miss it and no amount of clever copy recovers it.

**2. You are almost never the one standing there.** Your crew chief is. That means the
system has to work when handed to someone who does not care about your Google ranking and
will not remember a four-step process. If your review system requires you personally to be
on site, you do not have a system, you have an intention.

**3. Half your jobs are insurance jobs, and those have a different clock.** A homeowner
mid-claim is stressed and does not know yet whether you are the hero or another problem.
Asking then gets you silence at best. The window on an insurance job opens **after the
claim settles and the supplement is paid** — sometimes weeks after the roof is finished.

---

## The count that actually matters

Before you build anything, go look at what your competition has. Search your trade and
your town — *roofer in [your town]* — and write down the review count of the three
companies that show up in the map pack above you.

You are not trying to beat the regional outfit with 4,000 reviews. That company has ninety
crews and a marketing department and you will not catch them this year. **You are trying to
beat the roofer four miles away who has 61 reviews while you have 14.** That is the gap
that decides which of you the homeowner calls, and it is a gap you can close in a season.

Write both numbers down. Yours, and theirs. That is your target, and you will check it
again in ninety days.

---

## What Google actually allows — read this before you build anything

This is the part almost every review guide gets wrong, and getting it wrong can wipe every
review you have ever collected. All of it is straight from Google's own published policy.

**Allowed, and Google's own recommended method:** asking customers to visit a review link
or scan a QR code, and sharing that link on a printed card, a follow-up email, an invoice,
or a thank-you message.

**Prohibited — "Incentivized or Biased Reviews."** In Google's words, incentivized reviews
are *"reviews and ratings influenced by a payment, discount, free goods or services, or any
other benefit offered to the reviewer."* So no gift cards, no discount for a review, no
draw entry, no "$50 off your next repair if you leave us five stars." Google classes this
as fake and misleading content.

**Prohibited — review gating.** Gating is asking customers how they feel first, then only
sending the review link to the happy ones. It is extremely common in the trades, several
software products still sell it as a feature, and it is against policy. It also does not
work as well as people think: Google's own guidance is that *"a mix of positive and negative
feedback often feels more trustworthy."* A profile with nothing but flawless five-stars
reads as fake to homeowners.

**The rule this product runs on: the same link goes to every single customer, no screening.**
If that makes you nervous, that nervousness is information about the job, not about the
system.

**One more:** the customer must be signed in to a Google account to leave a review. They can
create one with any email address, not just Gmail. This is the single most common reason an
enthusiastic customer never actually posts.

---

## Setup — about twenty minutes, once

**Step 1 — get your official review link and QR code.**
Open your Google Business Profile and use **"Ask for reviews"**. Google generates both the
link and a QR code for you. Use Google's own — not a third-party generator. It is free,
it always points to the right place, and it cannot break when someone else's service shuts
down. Save the link somewhere you can paste it from your phone in two seconds: a note pinned
to your home screen, or a text shortcut.

**Step 2 — make the link one tap.** Set up a text-replacement shortcut on the crew phones
so typing something like `revlink` expands to the full URL. On iPhone that is Settings →
General → Keyboard → Text Replacement. If the crew has to hunt for the link, they will not
send it.

**Step 3 — print the cards.** Open `06-print-cards.html` in any browser, drop in your QR
code, and print. Four cards per sheet, cut them, and put a stack in every truck. See
`06-PRINT-CARDS-README.md`.

**Step 4 — brief the crew.** One sentence: *"When the homeowner comes out to look at the
finished roof and says something nice, hand them a card and say the line."* The line is in
`02-SCRIPTS.md` and it is fifteen seconds long. Do not give your crew a process. Give them
one sentence and one card.

**Step 5 — set up the follow-up.** One text, three days later, from the office. Not from
the crew. Template is in `02-SCRIPTS.md`.

---

## The run cycle

**On the job — the crew's part.** Final walkthrough, homeowner is looking at the roof.
Hand the card, say the line, leave. That is the entire crew responsibility. No app, no
tablet, no QR stand — Google has moved against on-site review kiosks and shared tablets,
so keep it to a card the homeowner takes away and scans on their own phone, later, in their
own time.

**That evening — the office's part.** Log the job in `05-tracker.csv`: name, address, crew
chief, date, whether the card was handed over. Thirty seconds a job.

**Three days later — the one follow-up.** Send the text. One. Then stop.

This is where almost everyone gets it wrong in both directions. Asking once and never
following up leaves most of your reviews uncollected, because people meant to and forgot.
Asking four times makes you the roofer who nags, and the fourth text is how you turn a
happy customer into a one-star. **One ask in person, one follow-up text, then let it go.**

**Within twenty-four hours of any review arriving — reply.** Every time, good or bad.
Templates in `03-REPLIES.md`. This is the highest-leverage ten minutes in the whole system
and it is the step people skip, because replying feels optional. It is not: your replies are
public, and the homeowner reading your profile six months from now is reading how you
handled the bad one.

**Insurance jobs — different clock.** Do not ask during the claim. Tag the job in the
tracker as insurance, and ask when the claim settles and the final payment clears. Send the
ask by text at that point rather than in person, since you will not be on site.

**Every ninety days — check the number.** Yours, and the roofer four miles away. That is the
only metric in this system.

---

## What to expect, honestly

Most roofers running this get a review from somewhere between a fifth and a third of the
customers they actually ask. The variable is not the script — it is whether the ask
happened at all. **The system fails at the crew step, not the copy step, essentially every
time.**

So if the numbers are not moving, do not rewrite the text message. Go and find out how many
cards left the truck. That single question explains nearly every underperforming review
system in the trades.

At twenty jobs a month with a fifth of asked customers responding, you are adding roughly
four reviews a month. That is 48 a year, which for most roofers is the difference between
being invisible and being the obvious choice in their town. **It compounds and it does not
stop, which is exactly why it is worth building once and running forever.**

---

## When to stop doing this yourself

You should run this manually for at least ninety days. You will learn what your customers
actually say, which crews hand out cards and which do not, and what your real response rate
is. That knowledge is worth more than any automation.

The moment it makes sense to automate is when the follow-up text stops going out reliably
because everyone is busy — usually somewhere north of forty jobs a month. At that point the
tracker becomes the bottleneck and you want the ask triggered automatically off your job
management system.

That is a real service and it costs real money, and you should not buy it until the manual
version has proven the ask is happening on site. **Automating a review system whose crews
are not handing out cards just automates the silence.**
