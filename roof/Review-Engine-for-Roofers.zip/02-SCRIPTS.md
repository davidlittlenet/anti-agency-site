# Scripts

Copy these, change the bracketed parts, use them. They are deliberately plain — the ones
that sound like marketing get ignored.

Two rules that apply to every script here:

- **Never mention the star rating you want.** Not "a five-star review", not "if we earned
  five stars". Ask for a review, not a rating. Asking for a specific rating is the line
  between asking and biasing, and biased reviews are a policy violation.
- **Never attach anything to it.** No discount, no draw, no free gutter clean, no "we'll
  knock $50 off". Google's policy names payment, discount, free goods or services and
  *"any other benefit"* as incentivized reviews, which is prohibited content.

---

## 1. The crew line — in person, at the final walkthrough

This is the one that matters. Fifteen seconds. The crew chief says it while handing over
the card, when the homeowner is looking at the finished roof.

> "Glad you're happy with it. If you've got a minute this week, a quick review on Google
> genuinely helps us out — the card's got a code you can scan with your phone camera.
> No pressure either way, and thanks for having us out."

Why it is built this way:

- **"Glad you're happy with it"** only works if they just said something positive. If they
  did not, skip the ask entirely — the tracker has a column for that, and a job that ends
  flat is a job to follow up on, not to request a review from.
- **"a minute this week"** sets an honest, small time cost and does not demand it now.
- **"genuinely helps us out"** is the actual reason and homeowners respond to it. Small
  local businesses get real goodwill from this; do not dress it up.
- **"the card's got a code"** moves the work to the card, so the crew never has to spell
  out a URL or handle someone's phone.
- **"No pressure either way"** is the part people cut, and it is the part that makes it
  land. It also keeps you the right side of the line, because it makes the ask genuinely
  optional.

**If the homeowner is not home at the walkthrough** — very common — the crew leaves the
card in the door or on the counter, and the ask moves to text. Log it either way.

---

## 2. The follow-up text — three days later, from the office

One text. Sent three days after the job, from the office phone, not the crew's.

> Hi [First name] — [Your name] from [Company]. Hope the new roof's looking good after the
> weekend. If you've got a second, we'd really appreciate a quick Google review: [link]
> Thanks again for choosing us.

Notes:

- **Three days** is deliberate. Same-day competes with the relief of the job being over,
  and a week later they have moved on.
- **Reference the actual job** — "the new roof", "the ridge vent", "getting that leak
  sorted". A text that could have been sent to anyone reads like a mass text, because it is.
- **The link goes last**, on its own. Do not bury it mid-sentence.
- **This is the only follow-up.** There is no second text. If they do not respond, they
  do not respond, and you keep the goodwill of a customer who will still refer you.

**Insurance-job variant**, sent after the claim settles and final payment clears:

> Hi [First name] — [Your name] at [Company]. Glad we got everything closed out with
> [insurer] and the roof squared away. That process is a lot to deal with, and if you've
> got a minute, a quick Google review would really help other homeowners going through the
> same thing: [link]

The claim experience is the thing they will actually want to talk about, and "helps other
homeowners going through the same thing" is true and is the strongest motivator you have
on storm work.

---

## 3. Email version — for commercial and property-manager jobs

Commercial contacts respond to email where homeowners respond to text.

**Subject:** Quick favour re: [property address]

> Hi [Name],
>
> Now that the work at [property address] is wrapped up, I wanted to say thanks for having
> us on it.
>
> If you were happy with how it went, would you mind leaving us a short Google review? It
> makes a real difference for us when other property managers are deciding who to call.
>
> [link]
>
> Either way, appreciate the business — give me a shout directly if anything comes up with
> the roof.
>
> [Your name]
> [Direct number]

---

## 4. On the invoice

One line at the bottom of every invoice and every final paperwork packet. It costs nothing
and it catches the customers who were happy but were not home at the walkthrough.

> **Happy with the work?** A quick Google review helps us more than you'd think: [link]
> *(or scan the code on the card we left)*

---

## 5. What to say when they say "sure, how?"

Roughly half the time the customer wants to and then never does, because they hit friction.
The friction is almost always the same one, so answer it before it happens:

> "Scan the code with your camera and it opens straight to the review box. Only thing is
> Google will ask you to be signed in — any email works for that, it doesn't have to be
> Gmail."

**This one sentence recovers more reviews than any other change you can make.** The
sign-in wall is where willing customers quietly give up, and almost nobody warns them.

---

## 6. The one you should not send

Do not send this, or anything shaped like it:

> ~~"How did we do? Reply 1-5. If you'd rate us a 5, here's our Google link — if not, let
> us know how we can fix it."~~

That is review gating: screening for sentiment and only routing the happy ones to Google.
It is against Google policy, plenty of tools still sell it as a feature, and the businesses
that get caught can lose every review they have collected.

It is also worse on its own terms. Ask everyone, reply well to the occasional bad one, and
you end up with a profile that homeowners believe. A wall of flawless five-stars reads as
purchased, and Google's own guidance says a mix of feedback feels more trustworthy.

If you want to catch problems before they become public reviews, do it properly: have the
crew chief ask *"anything you're not happy with?"* at the walkthrough, and fix it then.
That is quality control, and it is completely legitimate. What you cannot do is use the
answer to decide who gets the link.
