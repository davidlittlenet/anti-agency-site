# Reply templates

Reply to every review within twenty-four hours. Google's own guidance is that replies
should be short, personal, professional, and conversational rather than promotional — and
that you should not use a reply to push offers or deals.

**Who your replies are actually for:** not the reviewer. The homeowner reading your profile
six months from now, deciding whether to call you. That person will read your worst review
and your reply to it, and decide based on the reply.

Rotate the wording. Ten identical "Thank you for your business!" replies look automated
and Google explicitly advises against sending everyone the same thank-you.

---

## Five-star, with detail

> Thanks [First name] — really glad [specific thing they mentioned] worked out. [Crew
> chief's first name] and the guys will be happy to hear it. Give us a shout if anything
> comes up down the line. — [Your name]

Naming the crew chief is the highest-value thing you can put in a reply. It reads as a real
company with real people, and the crew see it.

## Five-star, no text — just the rating

> Thanks for the five stars, [First name] — appreciated. — [Your name]

Short is correct here. There is nothing to respond to, and padding it looks odd.

## Four-star

Do not ask what went wrong. It reads as ungrateful for a good review.

> Thanks [First name], appreciate you taking the time. Glad the roof's sorted — if there's
> anything still outstanding, call me direct on [number] and I'll get it handled.
> — [Your name]

## Three-star

> Thanks for the honest feedback, [First name]. [Acknowledge the specific issue.] That's
> not the standard we aim for and I'd like to put it right — I'm on [number] if you'll give
> me the chance. — [Your name]

## One and two-star — the one that matters

This is the reply future customers will read most closely. Four rules, all from Google's
published guidance: never share the reviewer's private information, never make it personal,
be honest about what was and was not in your control, and take it offline.

> [First name], I'm sorry — [specific thing] shouldn't have happened and I understand why
> you're frustrated. [One sentence, plainly, on what went wrong or what you've changed.]
> I'd like to make it right. I'm on [number] and I'll pick up personally. — [Your name]

What to avoid, because each of these actively costs you future customers:

- **Arguing the facts.** Even when you are right. The reader is not adjudicating, they are
  judging your temperament.
- **"We have no record of you in our system."** The single worst reply in the trades. It
  reads as calling the customer a liar, and it is the standard opener for defensive
  contractors. If you genuinely think it is not your customer, see the fake-review section
  below — do not litigate it in public.
- **Explaining your cancellation policy at length.** Nobody reads paragraph three.
- **Offering a discount to remove it.** Paying for a review change is exactly what the
  incentivized-reviews policy prohibits.

## Weather, supply and schedule complaints

Common in roofing and mostly not your fault, but "not our fault" is a bad reply. Google's
guidance is to acknowledge what happened, be honest about limitations, and explain what you
can and cannot control.

> Thanks for the feedback [First name], and I'm sorry the schedule slipped. We won't tear
> off a roof with storms forecast — it does mean delays, and I know that's frustrating when
> you've booked time off. We could have kept you better updated and that part's on us.
> — [Your name]

Conceding the part that is genuinely yours — the communication — is what makes the rest
credible.

## Insurance-claim frustration

> [First name], I hear you — claims are a slog and I'm sorry it dragged. We push the
> adjusters as hard as we're able but we don't control their timeline, which I know isn't
> much comfort when you're the one waiting. Glad the roof itself came out right. — [Your name]

---

## Reviews you believe are fake or not your customer

It happens: a competitor, a mistaken-identity review meant for a similarly named company,
or someone who never hired you.

1. **Flag it to Google first.** If a review violates Google's content policies you can
   report it — that is the documented route and it is the only one that can actually get it
   removed. Do this before you reply.
2. **Then reply once, calmly**, because removal is slow and uncertain and meanwhile people
   are reading it.

> We've got no record of work at this address and we think this may have been meant for
> another company — happy to be corrected. If you have dealt with us and I've got this
> wrong, please call me on [number], I'd genuinely like to sort it. — [Your name]

That wording works because it states your position, leaves room to be wrong, and does not
call anyone a liar. **Never accuse a competitor in public.** You cannot prove it, and it
makes you look worse than the review did.

Do not buy reviews to bury a bad one. Beyond being prohibited, purchased reviews arrive in
a recognisable burst and put your whole profile at risk — including the genuine reviews you
worked for.
