# What gets your reviews wiped

One page. Read it once, then keep it where whoever handles your marketing can see it.

Every item here is from Google's published policy, not from opinion. The reason it matters
is that enforcement is not surgical: Google can remove a batch of reviews or restrict a
profile, and the genuine reviews you spent two years earning go with the bad ones.

---

## The seven

**1. Offering anything in exchange for a review.** Google defines incentivized reviews as
those *"influenced by a payment, discount, free goods or services, or any other benefit
offered to the reviewer."* That covers gift cards, discounts, entries into a draw, a free
gutter clean, and "we'll take $50 off". It is classed as fake and misleading content.

**2. Review gating.** Asking how they feel first and only sending the link to the happy
ones. Common in the trades, sold as a feature by several tools, still against policy.

**3. Asking for a specific star rating.** "If we earned five stars…" biases the review.
Ask for a review; do not name the number.

**4. Review stations, kiosks and shared tablets on site.** Handing a customer your iPad to
leave a review on the spot is no longer acceptable practice, and it produces a cluster of
reviews from one device and one location, which is exactly the footprint automated systems
look for. A card the homeowner takes away and scans later on their own phone is the
supported route.

**5. Buying reviews.** They arrive in a recognisable burst from unrelated accounts and put
the whole profile at risk. This includes the cheap "50 reviews for $99" services and it
includes reciprocal review-swap groups, which are a conflict of interest under the same
policy.

**6. Reviews from staff, family, and your own accounts.** Also a conflict of interest.
It is also obvious — reviewers with one review, no photo, posted the same week.

**7. Offering to fix a bad review for money, or paying to have one removed.** Paying a
reviewer to change or delete a review falls under the same incentivized-content rule as
paying for one in the first place.

---

## Things people think are against the rules but are not

- **Asking every single customer.** Encouraged. Google's own help pages tell you to remind
  customers with a link or QR code.
- **Asking more than once.** One follow-up is fine. It is a judgement call about being
  annoying, not a policy question.
- **Putting the link on invoices, emails, business cards, door hangers, yard signs and your
  website.** All fine.
- **Replying to negative reviews, including firmly.** Fine, as long as you are not abusive
  and do not publish the customer's private information.
- **Flagging reviews you believe break the rules.** That is the documented process. Use it.

---

## If it happens anyway

If reviews disappear or the profile gets restricted:

1. **Stop whatever generated them,** immediately, before anything else.
2. **Do not start a second profile.** Duplicate profiles for one location make the original
   problem much harder to fix.
3. **Use the appeal process** from inside your Google Business Profile.
4. **Expect it to take weeks**, and expect the first appeal to be refused if you cannot
   point to what changed.

The professionals who do reinstatement work charge somewhere between $150 and $800 a
listing, most of them only on success. That is a fair measure of both how hard this is to
undo and how much cheaper it is not to trip it in the first place.
