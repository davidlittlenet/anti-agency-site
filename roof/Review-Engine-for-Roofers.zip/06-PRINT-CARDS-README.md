# Printing your review cards

## What you need first

Your Google review QR code. Get it from your **Google Business Profile → "Ask for reviews"**
— Google makes both the link and the QR code for you, free.

Use Google's own QR code rather than a third-party generator. Free generators often route
through their own domain so they can charge you later or show ads, and if that company
disappears every card you printed stops working.

## Making the cards

1. Open **06-print-cards.html** by double-clicking it. It opens in your browser. It works
   offline and nothing is uploaded anywhere — the file never leaves your computer.
2. Type in your company name and phone number.
3. Change the headline and sub-line if you want. The defaults are fine.
4. Click **Choose File** and pick your QR code image.
5. Press **Print sheet**. Four cards per page.

Print settings: plain paper is fine, card stock is better if the crew is handing them over
in the weather. Print at 100% — do not let the printer shrink to fit, or the QR code can
get too small to scan reliably.

## Test one before you print a hundred

Print one sheet, then **scan the code with a phone that is not yours.** You want to confirm
two things: it opens the review box for the right business, and it does that on a phone
that is not already signed into your Google account.

This is worth the two minutes. A box of cards with a QR pointing at the wrong location, or
at a profile you no longer manage, is a season of missed reviews you never find out about.

## How many to print

A stack of twenty-five per truck, topped up monthly. They cost almost nothing and the whole
system fails when the truck runs out and nobody says anything.

## Keeping it current

Reprint if you change your phone number or company name. **The QR code itself does not need
reprinting** unless you create a new Google Business Profile — the link stays the same as
your review count grows.
